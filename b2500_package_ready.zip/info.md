# B2500 YAML-Paket

Dieses Repository liefert vollständige YAML-Dateien zur Integration von B2500-Geräten in Home Assistant.
- Unterstützt mehrere Geräteinstanzen
- Mit MQTT-Sensoren, Automationen und einem Dashboard